﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neelakshi_Student_Management_System
{
    class StudentItem
	{
     
			public double Id { get; set; }
			public string Name { get; set; }
		    public double Fees { get; set; }


	}
	}

